class SignoutController < ApplicationController
  def index
  end
end
