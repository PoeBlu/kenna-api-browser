class AboutController < ApplicationController
  def introduction
  end

  def authentication
  end

  def parameters
  end

  def data_types
  end

  def errors
  end

  def status_codes
  end
end
