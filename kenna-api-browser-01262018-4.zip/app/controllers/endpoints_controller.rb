class EndpointsController < ApplicationController
  def vulnerabilities
  end

  def assets
  end

  def asset_groups
  end

  def asset_tagging
  end

  def fixes
  end

  def connectors
  end

  def users
  end

  def roles
  end

  def clients
  end

  def data_exports
  end
end
